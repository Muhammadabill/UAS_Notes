package com.example.noteshandphone;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

// =================================================================
//          PERUBAHAN 1: Mewarisi dari BaseActivity
// =================================================================
public class NegaraActivity extends BaseActivity { // <-- Diubah dari AppCompatActivity

    // Komponen UI yang akan kita ubah secara dinamis
    private ImageView imgFlag;
    private TextView tvTitleCountry;
    private Button btnMasukNegara;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); // onCreate dari BaseActivity akan menerapkan bahasa
        setupStatusBar();
        setContentView(R.layout.activity_negara);

        initializeViews();

        // Mengambil data bahasa yang dikirim dari BahasaActivity
        Intent intent = getIntent();
        String languageCode = intent.getStringExtra("SELECTED_LANGUAGE");

        // Memperbarui UI (hanya bendera) berdasarkan data yang diterima
        updateUiBasedOnLanguage(languageCode);

        // Mengatur listener untuk tombol "MASUK"
        btnMasukNegara.setOnClickListener(v -> {
            Intent mainIntent = new Intent(NegaraActivity.this, MainActivity.class);
            startActivity(mainIntent);
            overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
            // Kunci alur onboarding dengan menutup semua activity sebelumnya
            finishAffinity();
        });
    }

    private void setupStatusBar() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(getResources().getColor(R.color.bg_cyan));
        }
    }

    private void initializeViews() {
        // Pastikan ID ini sesuai dengan yang ada di file activity_negara.xml
        imgFlag = findViewById(R.id.img_flag);
        tvTitleCountry = findViewById(R.id.tv_title_country);
        btnMasukNegara = findViewById(R.id.btn_masuk_negara);
    }

    /**
     * Fungsi utama untuk mengubah HANYA GAMBAR BENDERA berdasarkan kode bahasa.
     * Teks akan diubah secara otomatis oleh sistem dari file strings.xml.
     * @param langCode Kode bahasa ("id", "en", "ja").
     */
    private void updateUiBasedOnLanguage(String langCode) {
        // Memberi nilai default "id" untuk mencegah error jika data kosong
        if (langCode == null) {
            langCode = "id";
        }

        // =================================================================
        //          PERUBAHAN 2: Kode disederhanakan
        // =================================================================
        // Teks seperti "Selamat Datang" dan "MASUK" akan otomatis diubah
        // oleh BaseActivity menggunakan file strings.xml. Kita hanya perlu mengubah gambar.
        switch (langCode) {
            case "en": // Jika bahasa Inggris
                imgFlag.setImageResource(R.drawable.uk); // Ganti gambar bendera UK
                break;

            case "ja": // Jika bahasa Jepang
                imgFlag.setImageResource(R.drawable.japan); // Ganti gambar bendera Jepang
                break;

            case "id": // Jika bahasa Indonesia
            default:
                imgFlag.setImageResource(R.drawable.negara); // Ganti gambar bendera Indonesia
                break;
        }

        // Kita tidak perlu lagi mengatur teks di sini:
        // tvTitleCountry.setText("..."); <-- Dihapus
    }
}
