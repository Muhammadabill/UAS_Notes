package com.example.noteshandphone;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

// Activity ini TIDAK PERLU extends BaseActivity karena ia adalah PENGATUR bahasa.
public class BahasaActivity extends AppCompatActivity {

    private static final String LANG_INDONESIAN = "id";
    private static final String LANG_ENGLISH = "en";
    private static final String LANG_JAPANESE = "ja";

    private CardView cardIndonesia, cardEnglish, cardJapan;
    private Button btnLanjut;

    private CardView selectedCard = null;
    private String selectedLangCode = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupStatusBar();
        setContentView(R.layout.activity_bahasa);

        initializeViews();
        setupListeners();
    }

    private void setupStatusBar() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(getResources().getColor(R.color.bg_cyan));
        }
    }

    private void initializeViews() {
        cardIndonesia = findViewById(R.id.card_indonesia);
        cardEnglish = findViewById(R.id.card_english);
        cardJapan = findViewById(R.id.card_japan);
        btnLanjut = findViewById(R.id.btn_lanjut_main);
    }

    private void setupListeners() {
        cardIndonesia.setOnClickListener(v -> handleCardSelection(cardIndonesia, LANG_INDONESIAN));
        cardEnglish.setOnClickListener(v -> handleCardSelection(cardEnglish, LANG_ENGLISH));
        cardJapan.setOnClickListener(v -> handleCardSelection(cardJapan, LANG_JAPANESE));

        btnLanjut.setOnClickListener(v -> {
            if (selectedLangCode != null) {
                // 1. Simpan preferensi bahasa untuk penggunaan di masa depan
                saveLanguagePreference(selectedLangCode);

                // =================================================================
                //          PERUBAHAN: Memanggil metode statis dari BaseActivity
                // =================================================================
                // 2. Terapkan bahasa SEKARANG untuk Activity berikutnya
                BaseActivity.updateResources(this, selectedLangCode); // <-- Lebih bersih

                // 3. Pindah ke activity selanjutnya
                navigateToNegaraActivity();
            }
        });
    }

    private void handleCardSelection(CardView clickedCard, String langCode) {
        if (selectedCard != null) {
            resetCardState(selectedCard);
        }

        // Logika untuk memilih/membatalkan pilihan
        if (selectedCard == clickedCard) {
            selectedCard = null;
            selectedLangCode = null;
            hideContinueButton();
        } else {
            selectedCard = clickedCard;
            selectedLangCode = langCode;
            highlightSelectedCard(selectedCard);
            showContinueButton();
        }
    }

    private void highlightSelectedCard(CardView card) {
        card.setCardBackgroundColor(Color.parseColor("#E0E0E0")); // Warna abu-abu muda
        card.animate().scaleX(1.05f).scaleY(1.05f).setDuration(200).start();
    }

    private void resetCardState(CardView card) {
        card.setCardBackgroundColor(Color.WHITE);
        card.animate().scaleX(1.0f).scaleY(1.0f).setDuration(200).start();
    }

    private void showContinueButton() {
        if (btnLanjut.getVisibility() == View.VISIBLE) return;

        btnLanjut.setVisibility(View.VISIBLE);
        btnLanjut.animate()
                .alpha(1.0f)
                .scaleX(1.0f)
                .scaleY(1.0f)
                .setDuration(300)
                .setListener(null);
    }

    private void hideContinueButton() {
        btnLanjut.animate()
                .alpha(0f)
                .scaleX(0.9f)
                .scaleY(0.9f)
                .setDuration(300)
                .setListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        super.onAnimationEnd(animation);
                        btnLanjut.setVisibility(View.GONE);
                    }
                });
    }

    private void saveLanguagePreference(String langCode) {
        SharedPreferences prefs = getSharedPreferences("AppSettingsPrefs", MODE_PRIVATE);
        prefs.edit().putString("Language", langCode).apply();
    }

    private void navigateToNegaraActivity() {
        Intent intent = new Intent(BahasaActivity.this, NegaraActivity.class);
        // Menitipkan data bahasa agar NegaraActivity bisa menampilkan bendera yang benar
        intent.putExtra("SELECTED_LANGUAGE", selectedLangCode);
        startActivity(intent);
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }

    // =========================================================================
    //          PERUBAHAN: Menghapus metode updateResources dari sini
    // =========================================================================
    // Metode `updateResources` yang duplikat sudah dihapus.
    // Kita sekarang memanggil `BaseActivity.updateResources()` secara langsung.
}
