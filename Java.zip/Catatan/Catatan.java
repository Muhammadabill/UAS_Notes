package com.example.noteshandphone;

import java.io.Serializable;

// Implementasi Serializable agar objek Catatan bisa dikirim antar Activity
public class Catatan implements Serializable {

    private String judul;
    private String isi;
    private String namaFile; // Untuk menyimpan nama file unik dari catatan

    public Catatan(String judul, String isi, String namaFile) {
        this.judul = judul;
        this.isi = isi;
        this.namaFile = namaFile;
    }

    // Getter
    public String getJudul() {
        return judul;
    }

    public String getIsi() {
        return isi;
    }

    public String getNamaFile() {
        return namaFile;
    }

    // Setter
    public void setJudul(String judul) {
        this.judul = judul;
    }

    public void setIsi(String isi) {
        this.isi = isi;
    }
}
