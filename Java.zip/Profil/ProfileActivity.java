package com.example.noteshandphone;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class ProfileActivity extends BaseActivity {

    private EditText etNamaPengguna;
    private Button btnSimpanNama;
    private ImageView btnKembali;
    private ImageView navHome;
    private ImageView navProfile;

    public static final String PROFIL_PREFS = "ProfilPreferences";
    public static final String KUNCI_NAMA = "kunciNamaPengguna";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        // Inisialisasi semua elemen UI
        etNamaPengguna = findViewById(R.id.et_nama_pengguna);
        btnSimpanNama = findViewById(R.id.btn_simpan_nama);
        btnKembali = findViewById(R.id.btn_kembali_profil);
        navHome = findViewById(R.id.nav_home);
        navProfile = findViewById(R.id.nav_profile);

        muatNama();

        btnSimpanNama.setOnClickListener(v -> simpanNama());
        btnKembali.setOnClickListener(v -> finish());

        // =======================================================
        //          PEMBARUAN LOGIKA NAVIGASI BAWAH
        // =======================================================

        // 1. Ikon Home membawa pengguna kembali ke MainActivity
        navHome.setOnClickListener(v -> {
            // Membuat intent untuk kembali ke MainActivity
            Intent intent = new Intent(ProfileActivity.this, MainActivity.class);
            // Flag ini penting untuk mencegah tumpukan activity yang tidak perlu
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish(); // Menutup halaman profil saat ini
            overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
        });

        // 2. Ikon Profil menampilkan pesan karena sudah berada di halaman profil
        navProfile.setOnClickListener(v -> {
            Toast.makeText(this, "Anda sudah di halaman profil", Toast.LENGTH_SHORT).show();
        });
    }

    private void muatNama() {
        SharedPreferences prefs = getSharedPreferences(PROFIL_PREFS, Context.MODE_PRIVATE);
        String namaTersimpan = prefs.getString(KUNCI_NAMA, "");
        etNamaPengguna.setText(namaTersimpan);
    }

    private void simpanNama() {
        String nama = etNamaPengguna.getText().toString().trim();
        if (nama.isEmpty()) {
            etNamaPengguna.setError("Nama tidak boleh kosong");
            return;
        }

        SharedPreferences prefs = getSharedPreferences(PROFIL_PREFS, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(KUNCI_NAMA, nama);
        editor.apply();

        Toast.makeText(this, getString(R.string.nama_disimpan), Toast.LENGTH_SHORT).show();
        // Tidak perlu finish() otomatis agar pengguna tetap di halaman ini setelah menyimpan
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }
}
