package com.example.noteshandphone;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build; // <-- IMPORT BARU
import android.os.Bundle;
import android.view.Window; // <-- IMPORT BARU
import android.view.WindowManager; // <-- IMPORT BARU

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

/**
 * BaseActivity ini berfungsi sebagai fondasi untuk semua Activity lain.
 * Tujuannya adalah untuk memeriksa dan menerapkan bahasa yang tersimpan
 * dan mengatur tampilan status bar secara otomatis setiap kali sebuah Activity dibuat.
 */
public abstract class BaseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        // Panggil fungsi untuk menerapkan bahasa SEBELUM layout ditampilkan
        applyLanguage();
        super.onCreate(savedInstanceState);
        // =================================================================
        //          PEMBARUAN: Panggil setupStatusBar di sini
        // =================================================================
        setupStatusBar();
    }

    /**
     * Metode ini akan dipanggil setiap kali sebuah Activity di-resume (kembali ke layar).
     * Berguna jika pengguna mengubah bahasa dari pengaturan sistem saat aplikasi berjalan.
     */
    @Override
    protected void onResume() {
        super.onResume();
        // Terapkan lagi untuk memastikan konsistensi
        applyLanguage();
    }

    /**
     * Memuat kode bahasa dari SharedPreferences dan menerapkannya ke konfigurasi aplikasi.
     */
    private void applyLanguage() {
        SharedPreferences prefs = getSharedPreferences("AppSettingsPrefs", MODE_PRIVATE);
        // Muat kode bahasa yang tersimpan. Jika tidak ada, default ke "id" (Indonesia).
        String languageCode = prefs.getString("Language", "id");

        // Panggil metode statis untuk memperbarui bahasa
        updateResources(this, languageCode);
    }

    // =================================================================
    //          PEMBARUAN: Metode setupStatusBar dipindahkan ke sini
    // =================================================================
    /**
     * Mengatur warna status bar agar konsisten di seluruh aplikasi.
     */
    private void setupStatusBar() {
        // Cek jika versi Android adalah Lollipop (API 21) atau lebih tinggi
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(getResources().getColor(R.color.bg_cyan));
        }
    }


    /**
     * Metode statis untuk mengubah konfigurasi bahasa aplikasi.
     * Bisa dipanggil dari Activity manapun.
     * @param context Context dari Activity
     * @param language Kode bahasa (misal: "id", "en", "ja")
     */
    public static void updateResources(Context context, String language) {
        Locale locale = new Locale(language);
        Locale.setDefault(locale);

        Resources res = context.getResources();
        Configuration config = new Configuration(res.getConfiguration());
        config.setLocale(locale);

        // Perbarui konfigurasi resources
        res.updateConfiguration(config, res.getDisplayMetrics());
    }
}
