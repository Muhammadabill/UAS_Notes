package com.example.noteshandphone;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class CatatanAdapter extends RecyclerView.Adapter<CatatanAdapter.CatatanViewHolder> {

    private List<Catatan> daftarCatatan;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(Catatan catatan);
    }

    public CatatanAdapter(List<Catatan> daftarCatatan, OnItemClickListener listener) {
        this.daftarCatatan = daftarCatatan;
        this.listener = listener;
    }

    @NonNull
    @Override
    public CatatanViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_catatan, parent, false);
        return new CatatanViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CatatanViewHolder holder, int position) {
        Catatan catatan = daftarCatatan.get(position);
        holder.bind(catatan, listener);
    }

    @Override
    public int getItemCount() {
        return daftarCatatan.size();
    }

    static class CatatanViewHolder extends RecyclerView.ViewHolder {
        private TextView tvJudul;
        private TextView tvIsi;

        public CatatanViewHolder(@NonNull View itemView) {
            super(itemView);
            tvJudul = itemView.findViewById(R.id.tv_item_judul);
            tvIsi = itemView.findViewById(R.id.tv_item_isi);
        }

        public void bind(final Catatan catatan, final OnItemClickListener listener) {
            tvJudul.setText(catatan.getJudul().isEmpty() ? "Tanpa Judul" : catatan.getJudul());
            tvIsi.setText(catatan.getIsi());

            itemView.setOnClickListener(v -> listener.onItemClick(catatan));
        }
    }
}
