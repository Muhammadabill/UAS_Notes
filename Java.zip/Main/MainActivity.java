package com.example.noteshandphone;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inisialisasi semua elemen UI yang diperlukan
        LinearLayout itemSemuaICloud = findViewById(R.id.item_semua_icloud);
        LinearLayout itemCatatan = findViewById(R.id.item_catatan);
        ImageView navProfile = findViewById(R.id.nav_profile);
        ImageView navHome = findViewById(R.id.nav_home);

        // --- Fungsionalitas Daftar Utama ---
        itemSemuaICloud.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, DaftarCatatanActivity.class);
            startActivity(intent);
            overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
        });

        itemCatatan.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, CatatActivity.class);
            startActivity(intent);
            overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
        });

        // =======================================================
        //          PEMBARUAN LOGIKA NAVIGASI BAWAH
        // =======================================================

        // 1. Ikon Profil/User membuka halaman ProfileActivity
        navProfile.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ProfileActivity.class);
            startActivity(intent);
            overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
        });

        // 2. Ikon Home menampilkan pesan karena sudah berada di halaman utama
        navHome.setOnClickListener(v -> {
            Toast.makeText(MainActivity.this, getString(R.string.anda_sudah_di_halaman_utama), Toast.LENGTH_SHORT).show();
        });
    }
}
