package com.example.noteshandphone;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

// =================================================================
//          PERUBAHAN 1: Mewarisi dari BaseActivity
// =================================================================
public class WelcomeActivity extends BaseActivity { // <-- Diubah dari AppCompatActivity

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); // Penting! Memanggil onCreate dari BaseActivity untuk menerapkan bahasa

        setupStatusBar();
        setContentView(R.layout.activity_welcome);

        Button tombolMasuk = findViewById(R.id.btn_masuk_welcome);

        tombolMasuk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(WelcomeActivity.this, LokasiActivity.class);
                startActivity(intent);
                overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
            }
        });
    }

    private void setupStatusBar() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(getResources().getColor(R.color.bg_cyan));
        }
    }
}
