package com.example.noteshandphone;

import android.content.Context;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import java.io.FileOutputStream;
import java.io.OutputStreamWriter;

public class CatatActivity extends BaseActivity {

    private EditText etJudul;
    private EditText etIsiCatatan;
    private Catatan catatanSaatIni; // Variabel untuk menyimpan data catatan yang sedang diedit (jika ada)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Hapus setupStatusBar(), karena sudah ada di BaseActivity
        setContentView(R.layout.activity_catat);

        etJudul = findViewById(R.id.et_judul_catatan_1);
        etIsiCatatan = findViewById(R.id.et_isi_catatan_1);

        // Cek apakah Activity ini dibuka untuk MENGEDIT catatan yang ada
        // atau untuk MEMBUAT catatan baru.
        if (getIntent().hasExtra("CATATAN_TERPILIH")) {
            // MODE EDIT: Ambil data catatan yang dikirim dari daftar
            catatanSaatIni = (Catatan) getIntent().getSerializableExtra("CATATAN_TERPILIH");

            // Tampilkan judul dan isi dari catatan yang ada ke EditText
            etJudul.setText(catatanSaatIni.getJudul());
            etIsiCatatan.setText(catatanSaatIni.getIsi());

        } else {
            // MODE BUAT BARU: Tidak ada data yang dimuat.
            catatanSaatIni = null;
        }
    }

    private void simpanDataCatatan() {
        String judul = etJudul.getText().toString();
        String isi = etIsiCatatan.getText().toString();

        // Pencegahan: Jangan simpan file kosong jika pengguna tidak mengetik apa-apa
        if (judul.trim().isEmpty() && isi.trim().isEmpty()) {
            return;
        }

        String namaFile;
        if (catatanSaatIni != null) {
            // Jika sedang mengedit, gunakan nama file yang sama agar file lama tertimpa (diperbarui)
            namaFile = catatanSaatIni.getNamaFile();
        } else {
            // Jika ini catatan baru, buat nama file unik menggunakan waktu saat ini
            namaFile = "catatan_" + System.currentTimeMillis() + ".txt";
        }

        try {
            // Buka file di penyimpanan internal aplikasi
            FileOutputStream fos = openFileOutput(namaFile, Context.MODE_PRIVATE);
            OutputStreamWriter writer = new OutputStreamWriter(fos);

            // Tulis judul di baris pertama
            writer.write(judul);
            // Tulis karakter baris baru (\n)
            writer.write("\n");
            // Tulis isi catatan
            writer.write(isi);

            writer.flush();
            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
            // Gunakan string dari strings.xml untuk pesan error
            Toast.makeText(this, "Gagal menyimpan catatan", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Otomatis simpan setiap kali pengguna meninggalkan halaman
        simpanDataCatatan();
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }
}
