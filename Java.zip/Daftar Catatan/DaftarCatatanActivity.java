package com.example.noteshandphone;

import android.content.Intent;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class DaftarCatatanActivity extends BaseActivity {

    private RecyclerView recyclerView;
    private CatatanAdapter adapter;
    private List<Catatan> daftarCatatan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daftar_catatan);

        recyclerView = findViewById(R.id.recycler_view_catatan);
        FloatingActionButton fab = findViewById(R.id.fab_tambah_catatan);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        daftarCatatan = new ArrayList<>();

        // Setup listener untuk tombol FAB
        fab.setOnClickListener(v -> {
            // Membuka CatatActivity untuk membuat catatan BARU
            Intent intent = new Intent(DaftarCatatanActivity.this, CatatActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        muatSemuaCatatan(); // Muat ulang catatan setiap kali kembali ke halaman ini
    }

    private void muatSemuaCatatan() {
        daftarCatatan.clear();
        File directory = getFilesDir(); // Direktori internal aplikasi
        File[] files = directory.listFiles();

        if (files != null) {
            for (File file : files) {
                // Kita hanya akan membaca file yang berakhiran .txt
                if (file.getName().endsWith(".txt")) {
                    try {
                        // Membaca file
                        BufferedReader reader = new BufferedReader(new InputStreamReader(openFileInput(file.getName())));
                        String judul = reader.readLine(); // Baris pertama adalah judul
                        StringBuilder isiBuilder = new StringBuilder();
                        String line;
                        while ((line = reader.readLine()) != null) {
                            isiBuilder.append(line).append("\n");
                        }
                        reader.close();

                        // Hapus newline terakhir jika ada
                        String isi = isiBuilder.toString().trim();

                        // Tambahkan ke daftar
                        daftarCatatan.add(new Catatan(judul, isi, file.getName()));

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }

        // Setup adapter
        adapter = new CatatanAdapter(daftarCatatan, catatan -> {
            // Aksi saat item di-klik: buka CatatActivity untuk MENGEDIT
            Intent intent = new Intent(DaftarCatatanActivity.this, CatatActivity.class);
            intent.putExtra("CATATAN_TERPILIH", catatan); // Kirim objek catatan
            startActivity(intent);
        });
        recyclerView.setAdapter(adapter);
    }
}
